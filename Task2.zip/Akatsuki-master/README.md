# Akatsuki
![cloud](https://github.com/omkar7075/Akatsuki/assets/91741647/77b5f1b0-ce98-4c98-ad16-d7b0864dcfb6)


![1](https://github.com/omkar7075/Akatsuki/assets/91741647/01757ebd-2aaa-495f-aa02-09dbf2ecda98)
