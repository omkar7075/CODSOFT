import  pain from "./Image/pain.png"
import konan from "./Image/konan.png"
import obito from "./Image/obito.png"
import kakazu from "./Image/kakazu.png"
import sasori from "./Image/sasori.png"
import itachi from "./Image/itachi.png"
import orochimaru from "./Image/orochimaru.png"
import kisame from "./Image/kisame.png"
import hidan from "./Image/hidan.png"
import deidara from "./Image/deidara.png"
import zetsu from "./Image/zetsu.png"

import prev from "./prev.png"
import next from "./next.png"

export{ 
    pain,
    konan,
    obito,
    kakazu,
    sasori,
    itachi,
    orochimaru,
    kisame,
    hidan,
    deidara,
    zetsu,
    prev,
    next,
}
