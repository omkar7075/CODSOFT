import { useState } from 'react'
import './App.css'
import Home from "./LandingPage/Home"

function App() {


  return (
    <>
      <Home/>
    </>
  )
}

export default App
